<?php

require_once "Controllers/ControllerTemplate.php";

$template = new ControllerTemplate();
$template -> showTemplate();