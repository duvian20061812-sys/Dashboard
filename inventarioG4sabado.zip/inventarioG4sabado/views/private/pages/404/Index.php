<div class="container-fluid">

<!-- Incluye en el <head> -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Segmento 404 con "GIF" animado pixel art generado en canvas -->
<div id="error404" class="d-flex flex-column justify-content-center align-items-center vh-100 bg-dark text-white px-3 gap-3">
  <canvas id="errorGif" width="320" height="80" class="error-gif mb-3" aria-label="Error animado pixel art" role="img"></canvas>
  <h1 class="display-1 fw-bold mb-0 text-center" id="error-code">404</h1>
  <p class="fs-3 mb-3 text-center">¡Vaya! Esta página parece estar perdida en el espacio.</p>
  <button id="btn-home" class="btn btn-custom btn-lg">Volver al Inicio</button>
</div>

<script>
  // Estilos dinámicos
  const style = document.createElement('style');
  style.textContent = `
    #error404 {
      background: linear-gradient(135deg, #8e2de2, #ff416c);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      transition: background 0.5s ease;
      user-select: none;
      height: 100vh;
      width: 100vw;
      margin: 0;
      padding: 0;
      gap: 1rem;
      text-align: center;
    }
    #error404:hover {
      background: linear-gradient(135deg, #ff416c, #8e2de2);
    }
    #error-code {
      font-size: 10rem;
      text-shadow: 3px 3px 10px rgba(0,0,0,0.3);
      transition: transform 0.3s ease, color 0.3s ease;
      cursor: default;
      user-select: none;
      margin-bottom: 0;
    }
    #error-code:hover {
      transform: rotate(10deg) scale(1.1);
      color: #ffc107;
      text-shadow: 4px 4px 15px #ffc107;
    }
    .btn-custom {
      background: linear-gradient(45deg, #0062E6, #33AEFF);
      border: none;
      border-radius: 50px;
      box-shadow: 0 8px 15px rgba(0, 98, 230, 0.3);
      color: white;
      font-weight: 600;
      transition: all 0.3s ease;
      padding: 0.75rem 2.5rem;
      user-select: none;
    }
    .btn-custom:hover, .btn-custom:focus {
      background: linear-gradient(45deg, #33AEFF, #0062E6);
      box-shadow: 0 15px 20px rgba(51, 174, 255, 0.6);
      transform: translateY(-3px);
      outline: none;
      color: white;
    }
    .btn-custom:active {
      transform: translateY(-1px);
      box-shadow: 0 8px 10px rgba(0, 98, 230, 0.4);
    }
    .error-gif {
      image-rendering: pixelated;
      width: 320px;
      height: 80px;
      user-select: none;
      pointer-events: none;
      cursor: default;
      filter: drop-shadow(0 0 5px rgba(0,0,0,0.3));
      transition: transform 0.3s ease;
    }
    .error-gif:hover {
      transform: scale(1.05) rotate(-5deg);
      filter: drop-shadow(0 0 10px #ffc107);
    }
    @media (max-width: 576px) {
      #error-code {
        font-size: 6rem;
      }
      .error-gif {
        width: 240px;
        height: 60px;
      }
    }
  `;
  document.head.appendChild(style);

  // Botón volver al inicio
  const btnHome = document.getElementById('btn-home');
  btnHome.addEventListener('click', () => {
    window.location.href = '/'; // Cambia a la URL de inicio de tu sitio
  });

  // Animación canvas para texto pixel art "ERROR"
  const canvas = document.getElementById('errorGif');
  const ctx = canvas.getContext('2d');

  // Pixel font style: blocky letters made with rectangles
  // We'll animate a simple flicker effect on the letters

  // Define pixel size and letter patterns (5x7 grid per letter)
  const pixelSize = 8;
  const letterSpacing = 4;
  const letters = {
    E: [
      [1,1,1,1,1],
      [1,0,0,0,0],
      [1,1,1,1,0],
      [1,0,0,0,0],
      [1,0,0,0,0],
      [1,0,0,0,0],
      [1,1,1,1,1],
    ],
    R: [
      [1,1,1,1,0],
      [1,0,0,0,1],
      [1,0,0,0,1],
      [1,1,1,1,0],
      [1,0,1,0,0],
      [1,0,0,1,0],
      [1,0,0,0,1],
    ],
    O: [
      [0,1,1,1,0],
      [1,0,0,0,1],
      [1,0,0,0,1],
      [1,0,0,0,1],
      [1,0,0,0,1],
      [1,0,0,0,1],
      [0,1,1,1,0],
    ],
  };

  // The word "ERROR" letters sequence
  const word = ['E','R','R','O','R'];

  // Colors for flicker effect
  const baseColor = '#ff3b3b'; // bright red
  const flickerColors = ['#ff3b3b', '#ff0000', '#cc0000', '#ff4d4d'];

  // Draw a single letter at (x,y)
  function drawLetter(letter, x, y, color) {
    const pattern = letters[letter];
    if(!pattern) return;
    ctx.fillStyle = color;
    for(let row=0; row<pattern.length; row++) {
      for(let col=0; col<pattern[row].length; col++) {
        if(pattern[row][col]) {
          ctx.fillRect(x + col*pixelSize, y + row*pixelSize, pixelSize, pixelSize);
        }
      }
    }
  }

  // Animate flicker
  let frame = 0;
  function animate() {
    ctx.clearRect(0,0,canvas.width,canvas.height);
    let x = 0;
    for(let i=0; i<word.length; i++) {
      // Flicker color changes per letter and frame
      const flickerIndex = (frame + i*3) % flickerColors.length;
      drawLetter(word[i], x, 0, flickerColors[flickerIndex]);
      x += 5*pixelSize + letterSpacing;
    }
    frame++;
    requestAnimationFrame(animate);
  }

  animate();
</script>
</div>
