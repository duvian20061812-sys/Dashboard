<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">
        Crear ventas
    </h1>

</div>