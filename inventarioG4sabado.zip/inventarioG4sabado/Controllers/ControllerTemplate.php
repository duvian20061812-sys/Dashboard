<?php

class ControllerTemplate{

    public function showTemplate(){
        include "views/template.php";
    }
}